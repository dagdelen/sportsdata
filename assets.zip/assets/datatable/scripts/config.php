<?php
$db_username 	= 'root';
$db_password 	= 'dagdelen';
$db_name 		= 'dt';
$db_host 		= 'localhost';
?>